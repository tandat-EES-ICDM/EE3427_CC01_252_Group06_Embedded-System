#ifndef BSP_NV_H
#define BSP_NV_H

#include "app_types.h"
#include "app_config.h"
#include <stdint.h>

// Gan cau hinh mac dinh cho 1 alarm
void BSP_NV_DefaultAlarm(alarm_cfg_t *cfg);

// Gan cau hinh mac dinh cho nhieu alarm
void BSP_NV_DefaultAlarms(alarm_cfg_t alarms[], uint8_t count);

// Doc danh sach alarm tu flash noi STM32
// Tra ve 0 neu doc OK, khac 0 neu flash chua co data hop le / loi
int BSP_NV_LoadAlarms(alarm_cfg_t alarms[], uint8_t count);

// Luu danh sach alarm xuong flash noi STM32
// Tra ve 0 neu luu OK, gia tri am neu loi erase/program/verify
int BSP_NV_SaveAlarms(const alarm_cfg_t alarms[], uint8_t count);

// Cac ham debug de hien thi tren LCD khi can kiem tra loi luu flash
uint16_t BSP_NV_GetFlashSizeKB(void);
uint32_t BSP_NV_GetStorageBase(void);
uint16_t BSP_NV_GetSlotCount(void);
uint16_t BSP_NV_GetUsedSlotCount(void);
uint32_t BSP_NV_GetLastSequence(void);
uint8_t BSP_NV_CountEnabledAlarms(const alarm_cfg_t alarms[], uint8_t count);

// Cac ham cu de giu tuong thich voi code cu: chi thao tac alarm so 1
int BSP_NV_LoadAlarm(alarm_cfg_t *cfg);
int BSP_NV_SaveAlarm(const alarm_cfg_t *cfg);

#endif
