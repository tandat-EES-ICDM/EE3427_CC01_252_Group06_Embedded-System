#ifndef APP_CONFIG_H
#define APP_CONFIG_H

#include "main.h"

// Group 1: LCD pin mapping
#define LCD_RS_GPIO           GPIOB
#define LCD_RS_PIN            GPIO_PIN_0	// PB0 = LCD_RS
#define LCD_E_GPIO            GPIOB
#define LCD_E_PIN             GPIO_PIN_1	// PB1 = LCD_E
#define LCD_BL_GPIO           GPIOB
#define LCD_BL_PIN            GPIO_PIN_8	// PB8 = LCD backlight
#define LCD_D4_GPIO           GPIOB
#define LCD_D4_PIN            GPIO_PIN_10	// PB10 = LCD_D4
#define LCD_D5_GPIO           GPIOB
#define LCD_D5_PIN            GPIO_PIN_11	// PB11 = LCD_D5
#define LCD_D6_GPIO           GPIOB
#define LCD_D6_PIN            GPIO_PIN_12	// PB12 = LCD_D6
#define LCD_D7_GPIO           GPIOB
#define LCD_D7_PIN            GPIO_PIN_13	// PB13 = LCD_D7
#define LCD_BACKLIGHT_PRESENT 1

// Group 2: Button pin mapping
#define BTN_SET_TIME_GPIO     GPIOA
#define BTN_SET_TIME_PIN      GPIO_PIN_0	// PA0 = SET_TIME
#define BTN_UP_GPIO           GPIOA
#define BTN_UP_PIN            GPIO_PIN_1	// PA1 = UP
#define BTN_DOWN_GPIO         GPIOA
#define BTN_DOWN_PIN          GPIO_PIN_2	// PA2 = DOWN
#define BTN_SET_ALARM_GPIO    GPIOA
#define BTN_SET_ALARM_PIN     GPIO_PIN_3	// PA3 = SET_TIME

// Group 3: Buzzer pin mapping
#define BUZZ_GPIO             GPIOA
#define BUZZ_PIN              GPIO_PIN_8	// PA8 = Buzzer

// Group 4: RTC line mapping
#define RTC_SCL_GPIO          GPIOB
#define RTC_SCL_PIN           GPIO_PIN_6	// PB6 = SCL
#define RTC_SDA_GPIO          GPIOB
#define RTC_SDA_PIN           GPIO_PIN_7	// PB7 = SDA

// Group 5: time constant of application
#define APP_UI_PERIOD_MS         50U	// every 50ms -> refresh UI
#define APP_BLINK_PERIOD_MS      300U	// every 300ms -> change blink state
#define APP_BTN_REPEAT_MS        100U	// when holding UP/DOWN, every 100ms -> UP/DOWN once
#define APP_BUZZ_ON_MS           300U	// Buzzer is ON for 300ms
#define APP_BUZZ_OFF_MS          100U	// Buzzer is OFF for 100ms
#define APP_BUZZ_TOTAL_MS        60000U	// Total ringing time = 60000 ms = 60s = 1 min

// Group 6: RTC config
#define RTC_I2C_ADDR_7BIT        0x68U	// 7-bit I2C addr of RTC DS1307/DS3231
#define RTC_I2C_ADDR_HAL         (RTC_I2C_ADDR_7BIT << 1)	// 0x68 << 1 = 0xD0

// Group 7: default time for RTC
// if RTC is error or trash value -> RTC module can use this for default value
#define RTC_DEFAULT_YEAR         2026U
#define RTC_DEFAULT_MONTH        3U
#define RTC_DEFAULT_DATE         24U
#define RTC_DEFAULT_HOUR         12U
#define RTC_DEFAULT_MIN          34U
#define RTC_DEFAULT_SEC          50U

// Group 8: alarm / non-volatile storage config
#define APP_MAX_ALARMS           3U              // Luu toi da 3 alarm
#define APP_USE_FLASH_NV_STORAGE 1               // ON/OFF to save alarm into internal flash of STM32
#define APP_NV_FLASH_BASE        0x0800FC00UL    // Fallback: last 1KB page if dynamic base is OFF
#define APP_NV_FLASH_PAGE_SIZE   1024UL          // STM32F103 medium-density page size = 1KB
#define APP_NV_USE_DYNAMIC_FLASH_BASE 0          // STM32F103C8T6: force fixed 64KB last page 0x0800FC00
#define APP_NV_MAGIC             0x434C4B33UL    // CLK3: log-based multi-alarm storage
#define APP_NV_VERSION           3U              // Version data luu flash

#endif
