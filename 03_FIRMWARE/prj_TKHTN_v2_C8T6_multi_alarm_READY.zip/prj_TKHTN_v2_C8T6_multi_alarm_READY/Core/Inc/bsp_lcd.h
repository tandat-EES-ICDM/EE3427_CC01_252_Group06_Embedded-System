#ifndef BSP_LCD_H
#define BSP_LCD_H

#include "main.h"
#include <stdint.h>

void BSP_LCD_Init(void);
void BSP_LCD_Clear(void);
void BSP_LCD_WriteLine(uint8_t row, const char *buf16);
void BSP_LCD_WriteTwoLines(const char *line0, const char *line1);
void BSP_LCD_CreateChar(uint8_t location, const uint8_t pattern[8]);

#endif
