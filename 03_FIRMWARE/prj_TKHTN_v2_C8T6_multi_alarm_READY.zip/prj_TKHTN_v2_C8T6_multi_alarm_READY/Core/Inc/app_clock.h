#ifndef APP_CLOCK_H
#define APP_CLOCK_H

void APP_CLOCK_Init(void);
void APP_CLOCK_Task(void);

#endif
