#ifndef BSP_RTC_H
#define BSP_RTC_H

#include "app_types.h"
#include <stdint.h>

int BSP_RTC_ReadDateTime(rtc_datetime_t *dt);
int BSP_RTC_WriteDateTime(const rtc_datetime_t *dt);
int BSP_RTC_ReadTemperatureC(int *temp_c);
int BSP_RTC_ProbeAndInitDefault(void);
uint8_t BSP_RTC_CalcDow(uint16_t year, uint8_t month, uint8_t date);

#endif
