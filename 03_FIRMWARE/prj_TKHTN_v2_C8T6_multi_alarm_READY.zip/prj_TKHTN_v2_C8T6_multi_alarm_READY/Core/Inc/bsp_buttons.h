#ifndef BSP_BUTTONS_H
#define BSP_BUTTONS_H

#include "main.h"
#include <stdint.h>

typedef enum {
    BSP_BUTTON_SET_TIME = 0,
    BSP_BUTTON_UP,
    BSP_BUTTON_DOWN,
    BSP_BUTTON_SET_ALARM,
    BSP_BUTTON_COUNT
} bsp_button_id_t;

void BSP_BUTTONS_Init(void);
void BSP_BUTTONS_Task(void);
uint8_t BSP_BUTTONS_WasPressed(bsp_button_id_t id);
uint8_t BSP_BUTTONS_IsHeld(bsp_button_id_t id);

#endif
