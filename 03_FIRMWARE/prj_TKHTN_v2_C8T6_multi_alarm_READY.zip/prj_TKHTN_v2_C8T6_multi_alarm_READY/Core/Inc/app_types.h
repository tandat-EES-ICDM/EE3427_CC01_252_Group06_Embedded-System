#ifndef APP_TYPES_H
#define APP_TYPES_H

#include "main.h"
#include <stdint.h>

// Struct contains data of date, time
typedef struct {
    uint8_t sec;
    uint8_t min;
    uint8_t hour;
    uint8_t dow;	// day of week
    uint8_t date;
    uint8_t month;
    uint16_t year;
} rtc_datetime_t;

// Struct contains alarm config
typedef struct {
    uint8_t hour;
    uint8_t min;
    uint8_t sec;
    uint8_t enabled;
} alarm_cfg_t;

#endif
