#include "app_clock.h"     // Header của module app_clock
#include "app_config.h"    // Cấu hình chung: macro, pin, giá trị mặc định...
#include "app_types.h"     // Các kiểu dữ liệu của project
#include "bsp_buttons.h"   // Driver nút bấm
#include "bsp_lcd.h"       // Driver LCD1602
#include "bsp_nv.h"        // Driver lưu dữ liệu không mất nguồn (flash nội STM32)
#include "bsp_rtc.h"       // Driver RTC DS3231/DS1307 (software I2C)
#include <string.h>        // Hàm xử lý chuỗi/bộ nhớ như memset, memcpy
#include <stdio.h>         // Hàm format chuỗi như snprintf

// Ký tự custom hình nhiệt kế cho LCD1602
// Mỗi phần tử là 1 hàng pixel trong ma trận 5x8
static const uint8_t g_thermometer_symbol[8] = {
    0b00100, 0b01010, 0b01010, 0b01110,
    0b01110, 0b11111, 0b11111, 0b01110
};

// Ký tự custom hình chuông báo thức cho LCD1602
// Dùng để hiển thị trạng thái alarm
static const uint8_t g_bell_symbol[8] = {
    0b00100, 0b01110, 0b01110, 0b01110,
    0b01110, 0b11111, 0b01000, 0b00100
};

static rtc_datetime_t g_now;   // Thời gian hiện tại đọc từ RTC
static alarm_cfg_t g_alarms[APP_MAX_ALARMS]; // Danh sach cac alarm hien tai
static uint8_t g_alarm_edit_index = 0U;      // Alarm dang duoc chinh: 0..APP_MAX_ALARMS-1

// Các biến tạm dùng khi user vào chế độ chỉnh ngày giờ
static int g_hh = 0;           // giờ tạm
static int g_mm = 0;           // phút tạm
static int g_ss = 0;           // giây tạm
static int g_dd = 1;           // ngày tạm
static int g_bb = 1;           // tháng tạm
static int g_yy = 2000;        // năm tạm
static int g_dow = 1;          // thứ tạm

// Trạng thái giao diện / mode chỉnh / blink / auto repeat nút
static uint8_t g_set_mode = 0U;        // mode chỉnh time/date
static uint8_t g_set_alarm_mode = 0U;  // mode chỉnh alarm
static uint32_t g_t_last_ui = 0U;      // thời điểm user thao tác gần nhất
static uint32_t g_t_last_blink = 0U;   // thời điểm đổi trạng thái blink gần nhất
static uint32_t g_t_last_repeat = 0U;  // thời điểm auto-repeat nút gần nhất
static uint8_t g_blink_visible = 1U;   // cờ đang hiện/ẩn phần đang blink

// Trạng thái đầu ra báo thức (buzzer)
static uint8_t g_alarm_output_active = 0U;     // alarm output đang hoạt động hay không
static uint32_t g_alarm_output_start_ms = 0U;  // thời điểm bắt đầu kêu alarm
static uint32_t g_alarm_tone_ms = 0U;          // mốc thời gian để tạo nhịp beep
static uint8_t g_buzz_pin_on = 0U;             // chân buzzer hiện đang ON hay OFF
static uint32_t g_last_alarm_signature = 0xFFFFFFFFUL; // Dau nhan dien alarm lan gan nhat de tranh trigger lap

// Buffer text cho 2 dòng LCD1602
static char g_line0[17];   // dòng 0: 16 ký tự + ký tự kết thúc chuỗi
static char g_line1[17];   // dòng 1: 16 ký tự + ký tự kết thúc chuỗi

static void fill_spaces(char *buf16)
{
    // Ghi 16 dấu cách vào toàn bộ vùng hiển thị của 1 dòng LCD
    for (int i = 0; i < 16; i++) {
        buf16[i] = ' ';
    }

    // Ký tự kết thúc chuỗi C
    buf16[16] = '\0';
}

static void blank_range(char *buf16, uint8_t start, uint8_t length)
{
    // Xóa trắng một đoạn trong buffer, bắt đầu từ vị trí start
    // và kéo dài length ký tự
    for (uint8_t i = 0U; i < length; i++) {

        // Chỉ xóa nếu còn nằm trong 16 vị trí hiển thị hợp lệ
        if ((start + i) < 16U) {
            buf16[start + i] = ' ';
        }
    }
}

static const char *dow_str3(uint8_t dow)
{
    // Đổi số thứ trong tuần thành chuỗi 3 ký tự để hiển thị LCD
    switch (dow) {
        case 1U: return "Sun";   // Chủ nhật
        case 2U: return "Mon";   // Thứ hai
        case 3U: return "Tue";   // Thứ ba
        case 4U: return "Wed";   // Thứ tư
        case 5U: return "Thu";   // Thứ năm
        case 6U: return "Fri";   // Thứ sáu
        case 7U: return "Sat";   // Thứ bảy
        default: return "   ";   // Nếu không hợp lệ thì trả 3 dấu cách
    }
}

static alarm_cfg_t *current_edit_alarm(void)
{
    // Tra ve con tro toi alarm dang duoc chinh hien tai.
    // Vi du g_alarm_edit_index = 0 thi dang chinh Alarm 1.
    if (g_alarm_edit_index >= APP_MAX_ALARMS) {
        g_alarm_edit_index = 0U;
    }

    return &g_alarms[g_alarm_edit_index];
}

static uint8_t any_alarm_enabled(void)
{
    // Chi can co it nhat 1 alarm dang bat thi man hinh chinh hien icon chuong.
    for (uint8_t i = 0U; i < APP_MAX_ALARMS; i++) {
        if (g_alarms[i].enabled != 0U) {
            return 1U;
        }
    }

    return 0U;
}


static void sync_edit_buffer_from_rtc(const rtc_datetime_t *dt)
{
    // Chép thời gian hiện tại từ struct RTC sang các biến tạm
    // để dùng trong chế độ chỉnh time/date
    g_hh = dt->hour;    // giờ tạm
    g_mm = dt->min;     // phút tạm
    g_ss = dt->sec;     // giây tạm
    g_dd = dt->date;    // ngày tạm
    g_bb = dt->month;   // tháng tạm
    g_yy = dt->year;    // năm tạm

    // Tính lại thứ trong tuần từ năm-tháng-ngày
    // thay vì copy thẳng dt->dow để đảm bảo đồng bộ
    g_dow = BSP_RTC_CalcDow(dt->year, dt->month, dt->date);
}

static void wrap_time_edit_fields(void)
{
    // Wrap giờ trong khoảng 0..23
    if (g_hh > 23) g_hh = 0;
    if (g_hh < 0)  g_hh = 23;

    // Wrap phút trong khoảng 0..59
    if (g_mm > 59) g_mm = 0;
    if (g_mm < 0)  g_mm = 59;

    // Wrap giây trong khoảng 0..59
    if (g_ss > 59) g_ss = 0;
    if (g_ss < 0)  g_ss = 59;

    // Wrap thứ trong tuần trong khoảng 1..7
    if (g_dow > 7) g_dow = 1;
    if (g_dow < 1) g_dow = 7;

    // Wrap ngày trong tháng trong khoảng 1..31
    // Lưu ý: đây chỉ là wrap cơ bản, chưa xét số ngày thật của từng tháng
    if (g_dd > 31) g_dd = 1;
    if (g_dd < 1)  g_dd = 31;

    // Wrap tháng trong khoảng 1..12
    if (g_bb > 12) g_bb = 1;
    if (g_bb < 1)  g_bb = 12;

    // Wrap năm trong khoảng 2000..2099
    if (g_yy > 2099) g_yy = 2000;
    if (g_yy < 2000) g_yy = 2099;
}

static void wrap_alarm_edit_fields(void)
{
    alarm_cfg_t *a = current_edit_alarm();

    // Dam bao index alarm nam trong 0..APP_MAX_ALARMS-1
    if (g_alarm_edit_index >= APP_MAX_ALARMS) {
        g_alarm_edit_index = 0U;
    }

    // Co bat/tat alarm chi hop le la 0 hoac 1
    if (a->enabled > 1U) a->enabled = 0U;

    // Gio alarm hop le trong khoang 0..23
    if (a->hour > 23U) a->hour = 0U;

    // Phut alarm hop le trong khoang 0..59
    if (a->min > 59U) a->min = 0U;

    // Giay alarm hop le trong khoang 0..59
    if (a->sec > 59U) a->sec = 0U;
}

static void render_clock_screen(void)
{
    int temp_c;              // Nhiệt độ đọc từ RTC (độ C nguyên)
    const char *dow_text;    // Chuỗi thứ trong tuần, ví dụ "Sun"
    char temp_buf[6];        // Buffer tạm để đổi nhiệt độ số -> chuỗi
    int pos = 12;            // Vị trí bắt đầu ghi số nhiệt độ trên dòng 0

    // Xóa trắng 2 dòng LCD trước khi dựng nội dung mới
    fill_spaces(g_line0);
    fill_spaces(g_line1);

    // Dòng 0: HH:MM:SS
    g_line0[0] = (char)('0' + (g_hh / 10) % 10);
    g_line0[1] = (char)('0' + (g_hh % 10));
    g_line0[2] = ':';
    g_line0[3] = (char)('0' + (g_mm / 10) % 10);
    g_line0[4] = (char)('0' + (g_mm % 10));
    g_line0[5] = ':';
    g_line0[6] = (char)('0' + (g_ss / 10) % 10);
    g_line0[7] = (char)('0' + (g_ss % 10));
    g_line0[8] = ' ';

    // Nếu alarm đang bật thì hiện icon chuông, ngược lại để trống
    g_line0[9] = (any_alarm_enabled() != 0U) ? (char)2 : ' ';
    g_line0[10] = ' ';

    // Nếu đọc được nhiệt độ thì hiển thị icon nhiệt kế + giá trị nhiệt độ
    if (BSP_RTC_ReadTemperatureC(&temp_c) == 0) {
        g_line0[11] = (char)1;  // icon nhiệt kế

        // Đổi nhiệt độ số nguyên sang chuỗi text
        snprintf(temp_buf, sizeof(temp_buf), "%d", temp_c);

        // Chép chuỗi nhiệt độ vào dòng 0, bắt đầu từ cột 12
        for (int i = 0; (temp_buf[i] != '\0') && (pos < 15); i++, pos++) {
            g_line0[pos] = temp_buf[i];
        }

        // Thêm ký hiệu độ và chữ C nếu còn chỗ
        if (pos < 16) g_line0[pos++] = (char)0xDF;
        if (pos < 16) g_line0[pos++] = 'C';
    }

    // Lấy chuỗi thứ trong tuần, ví dụ "Sun"
    dow_text = dow_str3((uint8_t)g_dow);

    // Dòng 1: DOW DD/MM/YYYY
    g_line1[0] = ' ';
    g_line1[1] = dow_text[0];
    g_line1[2] = dow_text[1];
    g_line1[3] = dow_text[2];
    g_line1[4] = ' ';
    g_line1[5] = (char)('0' + (g_dd / 10) % 10);
    g_line1[6] = (char)('0' + (g_dd % 10));
    g_line1[7] = '/';
    g_line1[8] = (char)('0' + (g_bb / 10) % 10);
    g_line1[9] = (char)('0' + (g_bb % 10));
    g_line1[10] = '/';
    g_line1[11] = (char)('0' + (g_yy / 1000) % 10);
    g_line1[12] = (char)('0' + (g_yy / 100) % 10);
    g_line1[13] = (char)('0' + (g_yy / 10) % 10);
    g_line1[14] = (char)('0' + (g_yy % 10));
}

static void render_alarm_screen(void)
{
    alarm_cfg_t *a = current_edit_alarm();

    // Xoa trang 2 dong LCD truoc khi dung noi dung moi
    fill_spaces(g_line0);
    fill_spaces(g_line1);

    // Dong 0: Alarm 1 Enabled / Alarm 2 Disabled / Alarm 3 Enabled
    memcpy(&g_line0[0], "Alarm ", 6U);
    g_line0[6] = (char)('1' + g_alarm_edit_index);
    g_line0[7] = ' ';

    if (a->enabled == 0U) {
        memcpy(&g_line0[8], "Disabled", 8U);
    } else {
        memcpy(&g_line0[8], "Enabled ", 8U);
    }

    // Dong 1 hien gio alarm dang chinh theo dang HH:MM:SS
    g_line1[4]  = (char)('0' + (a->hour / 10U) % 10U);
    g_line1[5]  = (char)('0' + (a->hour % 10U));
    g_line1[6]  = ':';
    g_line1[7]  = (char)('0' + (a->min / 10U) % 10U);
    g_line1[8]  = (char)('0' + (a->min % 10U));
    g_line1[9]  = ':';
    g_line1[10] = (char)('0' + (a->sec / 10U) % 10U);
    g_line1[11] = (char)('0' + (a->sec % 10U));
}

static void apply_blink_clock(void)
{
    // Nếu đang ở pha "hiện" của blink thì giữ nguyên nội dung,
    // không xóa gì cả
    if (g_blink_visible != 0U) {
        return;
    }

    // Nếu đang ở pha "ẩn" thì xóa trắng đúng field đang chỉnh
    switch (g_set_mode) {
        case 1U: blank_range(g_line0, 0U, 2U); break;   // blink giờ HH
        case 2U: blank_range(g_line0, 3U, 2U); break;   // blink phút MM
        case 3U: blank_range(g_line0, 6U, 2U); break;   // blink giây SS
        case 4U: blank_range(g_line1, 1U, 3U); break;   // blink thứ Sun/Mon/...
        case 5U: blank_range(g_line1, 5U, 2U); break;   // blink ngày DD
        case 6U: blank_range(g_line1, 8U, 2U); break;   // blink tháng MM
        case 7U: blank_range(g_line1, 11U, 4U); break;  // blink năm YYYY
        default: break;                                 // không ở mode chỉnh nào thì không làm gì
    }
}

static void apply_blink_alarm(void)
{
    // Neu dang o pha "hien" cua blink thi giu nguyen noi dung
    if (g_blink_visible != 0U) {
        return;
    }

    // Neu dang o pha "an" thi xoa trang dung field alarm dang chinh
    switch (g_set_alarm_mode) {
        case 1U: blank_range(g_line0, 6U, 1U); break;   // blink so thu tu alarm: 1/2/3
        case 2U: blank_range(g_line0, 8U, 8U); break;   // blink trang thai Enabled/Disabled
        case 3U: blank_range(g_line1, 4U, 2U); break;   // blink gio alarm
        case 4U: blank_range(g_line1, 7U, 2U); break;   // blink phut alarm
        case 5U: blank_range(g_line1, 10U, 2U); break;  // blink giay alarm
        default: break;
    }
}

static void stop_alarm_output(void)
{
    g_alarm_output_active = 0U;   // Không còn ở trạng thái alarm đang chạy
    g_buzz_pin_on = 0U;           // Trong logic phần mềm, buzzer đang OFF
    HAL_GPIO_WritePin(BUZZ_GPIO, BUZZ_PIN, GPIO_PIN_RESET); // Kéo chân buzzer xuống LOW để tắt
}

static void start_alarm_output(void)
{
    uint32_t now = HAL_GetTick(); // Lấy thời điểm hiện tại theo ms

    g_alarm_output_active = 1U;      // Đánh dấu alarm đang hoạt động
    g_alarm_output_start_ms = now;   // Lưu mốc bắt đầu cả phiên alarm
    g_alarm_tone_ms = now;           // Lưu mốc nhịp beep hiện tại
    g_buzz_pin_on = 1U;              // Trong logic phần mềm, buzzer đang ON
    HAL_GPIO_WritePin(BUZZ_GPIO, BUZZ_PIN, GPIO_PIN_SET); // Kéo chân buzzer lên HIGH để bật
}

static void update_alarm_output(void)
{
    uint32_t now = HAL_GetTick();

    // Tao chu ky nhan dien co ca ngay-thang-nam.
    // Neu chi dung HH:MM:SS thi ngay hom sau cung gio se bi xem la lap lai.
    uint32_t day_id = ((uint32_t)(g_yy - 2000) * 366UL) + ((uint32_t)g_bb * 31UL) + (uint32_t)g_dd;
    uint32_t signature = (day_id * 86400UL) + ((uint32_t)g_hh * 3600UL) + ((uint32_t)g_mm * 60UL) + (uint32_t)g_ss;
    uint8_t matched = 0U;

    // Neu dang chinh clock/alarm, hoac khong co alarm nao bat, thi tat buzzer
    if ((g_set_mode != 0U) || (g_set_alarm_mode != 0U) || (any_alarm_enabled() == 0U)) {
        stop_alarm_output();
        return;
    }

    // Kiem tra tat ca alarm dang luu
    for (uint8_t i = 0U; i < APP_MAX_ALARMS; i++) {
        if ((g_alarms[i].enabled != 0U) &&
            (g_hh == (int)g_alarms[i].hour) &&
            (g_mm == (int)g_alarms[i].min) &&
            (g_ss == (int)g_alarms[i].sec)) {
            matched = 1U;
            break;
        }
    }

    // Neu co alarm trung thoi diem hien tai va chua kich o dung giay nay thi bat buzzer
    if (matched != 0U) {
        if (signature != g_last_alarm_signature) {
            g_last_alarm_signature = signature;
            start_alarm_output();
        }
    }

    // Neu hien tai alarm output khong active thi khong can lam gi them
    if (g_alarm_output_active == 0U) {
        return;
    }

    // Neu da keu du tong thoi gian cho phep thi dung han
    if ((now - g_alarm_output_start_ms) >= APP_BUZZ_TOTAL_MS) {
        stop_alarm_output();
        return;
    }

    // Tao nhip beep: ON 300ms, OFF 100ms
    if (g_buzz_pin_on != 0U) {
        if ((now - g_alarm_tone_ms) >= APP_BUZZ_ON_MS) {
            g_buzz_pin_on = 0U;
            g_alarm_tone_ms = now;
            HAL_GPIO_WritePin(BUZZ_GPIO, BUZZ_PIN, GPIO_PIN_RESET);
        }
    } else {
        if ((now - g_alarm_tone_ms) >= APP_BUZZ_OFF_MS) {
            g_buzz_pin_on = 1U;
            g_alarm_tone_ms = now;
            HAL_GPIO_WritePin(BUZZ_GPIO, BUZZ_PIN, GPIO_PIN_SET);
        }
    }
}

static void save_time_to_rtc(void)
{
    rtc_datetime_t new_dt;  // Struct tạm để chứa bộ ngày giờ mới chuẩn bị ghi xuống RTC

    wrap_time_edit_fields();   // Ép các field đang chỉnh về khoảng hợp lệ trước khi save

    new_dt.hour = (uint8_t)g_hh;   // giờ
    new_dt.min = (uint8_t)g_mm;    // phút
    new_dt.sec = (uint8_t)g_ss;    // giây
    new_dt.date = (uint8_t)g_dd;   // ngày
    new_dt.month = (uint8_t)g_bb;  // tháng
    new_dt.year = (uint16_t)g_yy;  // năm

    // Tính lại thứ từ năm-tháng-ngày để đảm bảo đúng
    new_dt.dow = BSP_RTC_CalcDow(new_dt.year, new_dt.month, new_dt.date);

    // Đồng bộ lại biến thứ trong RAM
    g_dow = new_dt.dow;

    // Ghi toàn bộ struct new_dt xuống RTC
    // Ở đây code không kiểm tra giá trị trả về
    (void)BSP_RTC_WriteDateTime(&new_dt);
}

static void handle_set_logic(void)
{
    uint32_t now = HAL_GetTick(); // Lay thoi gian hien tai de xu ly auto-repeat nut
    alarm_cfg_t *a = current_edit_alarm();

    // Neu da di toi mode finish cua set time thi hien thong bao,
    // luu thoi gian xuong RTC, roi thoat mode set
    if (g_set_mode == 8U) {
        BSP_LCD_WriteTwoLines("Set Date Finish ", "Set Time Finish ");
        HAL_Delay(1000U);
        save_time_to_rtc();
        BSP_LCD_Clear();
        g_set_mode = 0U;
    }

    // Neu da di toi mode finish cua set alarm thi luu TAT CA alarm xuong flash
    if (g_set_alarm_mode == 6U) {
        int save_ret;
        int load_ret;
        alarm_cfg_t verify_alarms[APP_MAX_ALARMS];
        char err_line[17];

        wrap_alarm_edit_fields();
        save_ret = BSP_NV_SaveAlarms(g_alarms, APP_MAX_ALARMS);

        // Doc lai bang API LoadAlarms de kiem tra dung nhu luc khoi dong lai.
        load_ret = BSP_NV_LoadAlarms(verify_alarms, APP_MAX_ALARMS);
        if ((save_ret == 0) &&
            ((load_ret != 0) || (memcmp(verify_alarms, g_alarms, sizeof(g_alarms)) != 0))) {
            save_ret = -20; // save noi bo OK nhung load lai bang API khong khop
        }

        if (save_ret == 0) {
            char ok_line1[17];
            char tmp_line[24];
            fill_spaces(ok_line1);
            snprintf(tmp_line, sizeof(tmp_line), "E%u Slot %u/%u",
                     BSP_NV_CountEnabledAlarms(g_alarms, APP_MAX_ALARMS),
                     BSP_NV_GetUsedSlotCount(),
                     BSP_NV_GetSlotCount());
            {
                size_t n = strlen(tmp_line);
                if (n > 16U) n = 16U;
                memcpy(ok_line1, tmp_line, n);
            }
            BSP_LCD_WriteTwoLines("NV SAVE OK      ", ok_line1);
        } else {
            char tmp_line[24];
            fill_spaces(err_line);
            snprintf(tmp_line, sizeof(tmp_line), "NV ERR %d", save_ret);
            {
                size_t n = strlen(tmp_line);
                if (n > 16U) n = 16U;
                memcpy(err_line, tmp_line, n);
            }
            BSP_LCD_WriteTwoLines("FLASH SAVE FAIL ", err_line);
        }

        HAL_Delay(2500U);
        BSP_LCD_Clear();
        g_set_alarm_mode = 0U;
    }

    // Neu vua bam nut SET_TIME:
    // - dang chinh alarm thi coi nhu finish alarm
    // - khong thi chuyen sang field ke tiep cua set time
    if (BSP_BUTTONS_WasPressed(BSP_BUTTON_SET_TIME) != 0U) {
        if (g_set_alarm_mode > 0U) {
            g_set_alarm_mode = 6U;
        } else {
            g_set_mode++;
        }
    }

    // Neu vua bam nut SET_ALARM:
    // - dang chinh time thi coi nhu finish time
    // - khong thi chuyen sang field ke tiep cua set alarm
    if (BSP_BUTTONS_WasPressed(BSP_BUTTON_SET_ALARM) != 0U) {
        if (g_set_mode > 0U) {
            g_set_mode = 8U;
        } else {
            g_set_alarm_mode++;
            BSP_LCD_Clear();
        }
    }

    // Chi cho phep auto-repeat UP/DOWN moi APP_BTN_REPEAT_MS
    if ((now - g_t_last_repeat) < APP_BTN_REPEAT_MS) {
        return;
    }
    g_t_last_repeat = now;

    // Cap nhat lai con tro sau khi mode/index co the vua thay doi
    a = current_edit_alarm();

    // Neu dang giu nut UP
    if (BSP_BUTTONS_IsHeld(BSP_BUTTON_UP) != 0U) {
        if (g_set_alarm_mode == 0U) {
            // Tang field tuong ung cua time/date
            switch (g_set_mode) {
                case 1U: g_hh++; break;
                case 2U: g_mm++; break;
                case 3U: g_ss++; break;
                case 4U: g_dow++; break;
                case 5U: g_dd++; break;
                case 6U: g_bb++; break;
                case 7U: g_yy++; break;
                default: break;
            }
            wrap_time_edit_fields();
        } else {
            // Tang field tuong ung cua alarm dang chinh
            switch (g_set_alarm_mode) {
                case 1U:
                    g_alarm_edit_index++;
                    if (g_alarm_edit_index >= APP_MAX_ALARMS) g_alarm_edit_index = 0U;
                    break;
                case 2U:
                    a->enabled = 1U; // UP = bat alarm
                    break;
                case 3U:
                    a->hour++;
                    break;
                case 4U:
                    a->min++;
                    break;
                case 5U:
                    a->sec++;
                    break;
                default:
                    break;
            }
            wrap_alarm_edit_fields();
        }
    }

    // Neu dang giu nut DOWN
    if (BSP_BUTTONS_IsHeld(BSP_BUTTON_DOWN) != 0U) {
        if (g_set_alarm_mode == 0U) {
            // Giam field tuong ung cua time/date
            switch (g_set_mode) {
                case 1U: g_hh--; break;
                case 2U: g_mm--; break;
                case 3U: g_ss--; break;
                case 4U: g_dow--; break;
                case 5U: g_dd--; break;
                case 6U: g_bb--; break;
                case 7U: g_yy--; break;
                default: break;
            }
            wrap_time_edit_fields();
        } else {
            // Giam field tuong ung cua alarm dang chinh
            switch (g_set_alarm_mode) {
                case 1U:
                    g_alarm_edit_index = (uint8_t)((g_alarm_edit_index == 0U) ? (APP_MAX_ALARMS - 1U) : (g_alarm_edit_index - 1U));
                    break;
                case 2U:
                    a->enabled = 0U; // DOWN = tat alarm
                    break;
                case 3U:
                    a->hour = (uint8_t)((a->hour == 0U) ? 23U : (a->hour - 1U));
                    break;
                case 4U:
                    a->min = (uint8_t)((a->min == 0U) ? 59U : (a->min - 1U));
                    break;
                case 5U:
                    a->sec = (uint8_t)((a->sec == 0U) ? 59U : (a->sec - 1U));
                    break;
                default:
                    break;
            }
            wrap_alarm_edit_fields();
        }
    }
}

void APP_CLOCK_Init(void)
{
    // Nạp 2 ký tự custom vào LCD:
    // slot 1 = nhiệt kế, slot 2 = chuông
    BSP_LCD_CreateChar(1U, g_thermometer_symbol);
    BSP_LCD_CreateChar(2U, g_bell_symbol);

    // Hiện màn hình chào khi mới bật nguồn
    BSP_LCD_WriteTwoLines(" Real Time Clock ", " With Alarm      ");
    HAL_Delay(1500U);
    BSP_LCD_Clear();

    // Hien thong tin vung flash dang dung de debug loi mat alarm sau khi tat nguon
    {
        char line0[17];
        char line1[17];
        char tmp0[32];
        char tmp1[32];
        fill_spaces(line0);
        fill_spaces(line1);
        snprintf(tmp0, sizeof(tmp0), "Flash %uKB", BSP_NV_GetFlashSizeKB());
        snprintf(tmp1, sizeof(tmp1), "NV %08lX", (unsigned long)BSP_NV_GetStorageBase());
        {
            size_t n0 = strlen(tmp0);
            size_t n1 = strlen(tmp1);
            if (n0 > 16U) n0 = 16U;
            if (n1 > 16U) n1 = 16U;
            memcpy(line0, tmp0, n0);
            memcpy(line1, tmp1, n1);
        }
        BSP_LCD_WriteTwoLines(line0, line1);
        HAL_Delay(1200U);
        BSP_LCD_Clear();
    }

    // Doc danh sach alarm da luu tu flash vao RAM
    // Neu flash chua co data hop le thi BSP_NV_LoadAlarms se fallback ve default
    {
        int load_ret = BSP_NV_LoadAlarms(g_alarms, APP_MAX_ALARMS);
        char nv_line1[17];
        char tmp_line[24];

        // Man hinh debug ngan de biet sau khi reset STM32 co doc duoc alarm tu flash hay khong.
        if (load_ret == 0) {
            fill_spaces(nv_line1);
            snprintf(tmp_line, sizeof(tmp_line), "E%u Seq %lu",
                     BSP_NV_CountEnabledAlarms(g_alarms, APP_MAX_ALARMS),
                     (unsigned long)BSP_NV_GetLastSequence());
            {
                size_t n = strlen(tmp_line);
                if (n > 16U) n = 16U;
                memcpy(nv_line1, tmp_line, n);
            }
            BSP_LCD_WriteTwoLines("NV LOAD OK      ", nv_line1);
            HAL_Delay(1200U);
        } else {
            fill_spaces(nv_line1);
            snprintf(tmp_line, sizeof(tmp_line), "Load ret %d", load_ret);
            {
                size_t n = strlen(tmp_line);
                if (n > 16U) n = 16U;
                memcpy(nv_line1, tmp_line, n);
            }
            BSP_LCD_WriteTwoLines("NV DEFAULT USED ", nv_line1);
            HAL_Delay(1600U);
        }
        BSP_LCD_Clear();
    }

    // Kiểm tra RTC có đọc được và dữ liệu có hợp lệ không
    // Nếu lỗi thì hiện thông báo và dừng luôn
    if (BSP_RTC_ProbeAndInitDefault() != 0) {
        BSP_LCD_WriteTwoLines("RTC READ ERROR  ", "CHK SDA/SCL/RTC ");
        while (1) {
            HAL_Delay(200U);
        }
    }

    // Đọc ngày giờ hiện tại từ RTC vào g_now
    // Nếu lỗi thì hiện thông báo và dừng luôn
    if (BSP_RTC_ReadDateTime(&g_now) != 0) {
        BSP_LCD_WriteTwoLines("RAW READ FAIL   ", "CHK SDA/SCL/RTC ");
        while (1) {
            HAL_Delay(200U);
        }
    }

    // Đồng bộ các biến tạm dùng cho UI chỉnh sửa từ dữ liệu RTC hiện tại
    sync_edit_buffer_from_rtc(&g_now);

    // Đảm bảo buzzer đang tắt khi khởi động
    stop_alarm_output();
}

void APP_CLOCK_Task(void)
{
    uint32_t now = HAL_GetTick(); // Lấy thời gian hệ thống hiện tại theo ms

    BSP_BUTTONS_Task();   // Quét và debounce tất cả các nút
    handle_set_logic();   // Xử lý logic set time / set alarm dựa trên trạng thái nút

    // Nếu đã tới thời điểm đổi blink thì đảo trạng thái hiện/ẩn
    if ((now - g_t_last_blink) >= APP_BLINK_PERIOD_MS) {
        g_t_last_blink = now;
        g_blink_visible ^= 1U;
    }

    // Nếu đã tới thời điểm refresh UI thì cập nhật màn hình
    if ((now - g_t_last_ui) >= APP_UI_PERIOD_MS) {
        g_t_last_ui = now;

        // Chỉ đọc RTC khi KHÔNG đang chỉnh time/date
        // để tránh ghi đè dữ liệu user đang chỉnh
        if (g_set_mode == 0U) {
            if (BSP_RTC_ReadDateTime(&g_now) == 0) {
                sync_edit_buffer_from_rtc(&g_now); // Đồng bộ bộ đệm hiển thị từ RTC
            } else {
                // Nếu đọc RTC lỗi thì hiện thông báo lỗi rồi bỏ qua vòng này
                BSP_LCD_WriteTwoLines("RTC READ ERROR  ", "CHK SDA/SCL/RTC ");
                HAL_Delay(200U);
                return;
            }
        }

        // Nếu đang chỉnh alarm thì dựng màn hình alarm
        // ngược lại thì dựng màn hình clock
        if (g_set_alarm_mode > 0U) {
            render_alarm_screen();
            apply_blink_alarm();
        } else {
            render_clock_screen();
            apply_blink_clock();
        }

        // Ghi 2 dòng đã dựng ra LCD thật
        BSP_LCD_WriteTwoLines(g_line0, g_line1);
    }

    // Luôn cập nhật logic buzzer alarm
    update_alarm_output();
}
