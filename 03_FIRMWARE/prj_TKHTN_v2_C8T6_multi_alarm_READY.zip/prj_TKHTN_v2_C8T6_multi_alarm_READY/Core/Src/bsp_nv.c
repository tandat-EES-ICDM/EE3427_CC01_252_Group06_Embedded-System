#include "bsp_nv.h"      // Khai bao public cua module NV Storage
#include "app_config.h"  // Cau hinh project: magic, so alarm, dia chi flash
#include <stddef.h>      // Dung offsetof()
#include <string.h>      // Dung memset(), memcmp()

// Dia chi thanh ghi ROM cua STM32F1 chua dung luong flash that cua chip, don vi KB.
// Tren Blue Pill STM32F103C8T6 thuong la 64KB, nhung mot so board/clone co the bao 128KB.
#define NV_FLASHSIZE_REG_ADDR   0x1FFFF7E0UL
#define NV_FLASH_BASE_ADDR      0x08000000UL

#ifndef APP_NV_FLASH_PAGE_SIZE
#define APP_NV_FLASH_PAGE_SIZE  1024UL
#endif

#ifndef APP_NV_USE_DYNAMIC_FLASH_BASE
#define APP_NV_USE_DYNAMIC_FLASH_BASE 1
#endif

#define NV_SLOT_COMMIT_VALUE    0x0000U
#define NV_SLOT_EMPTY_VALUE     0xFFFFU

// Moi lan save se ghi vao 1 slot moi trong page flash.
// Cach nay han che erase flash: page trong thi chi program, khong erase lien tuc.
// Field commit duoc ghi CUOI CUNG de tranh mat dien giua chung tao thanh data nua chung.
typedef struct {
    uint32_t magic;                         // Ma nhan dang vung flash cua app
    uint32_t sequence;                      // So thu tu lan save, lan sau lon hon lan truoc
    uint8_t version;                        // Version format data
    uint8_t count;                          // So alarm duoc luu
    uint16_t reserved;                      // Dem cho can hang
    alarm_cfg_t alarms[APP_MAX_ALARMS];     // Danh sach alarm
    uint32_t checksum;                      // Checksum tinh tru commit
    uint16_t commit;                        // Ghi cuoi cung: 0x0000 = slot hop le
    uint16_t pad;                           // Dem de struct chan 4 byte
} nv_slot_t;

// Bien debug nho, de app hien thi neu can.
static uint32_t g_last_sequence = 0U;

static uint8_t nv_alarm_is_valid(const alarm_cfg_t *a)
{
    if (a->hour > 23U) return 0U;
    if (a->min > 59U) return 0U;
    if (a->sec > 59U) return 0U;
    if (a->enabled > 1U) return 0U;
    return 1U;
}

static uint32_t nv_checksum(const nv_slot_t *s)
{
    const uint8_t *p = (const uint8_t *)s;
    uint32_t x = 0x811C9DC5UL;
    uint32_t n = (uint32_t)offsetof(nv_slot_t, checksum);

    for (uint32_t i = 0U; i < n; i++) {
        x ^= (uint32_t)p[i];
        x *= 16777619UL;
    }

    return x ^ 0xA5A5A5A5UL;
}

uint16_t BSP_NV_GetFlashSizeKB(void)
{
    uint16_t kb = *((const volatile uint16_t *)NV_FLASHSIZE_REG_ADDR);

    // Chan cac gia tri rac de tranh tinh dia chi nguy hiem.
    // STM32F103C8 thuong 64KB; neu doc ra bat thuong thi fallback ve 64KB.
    if ((kb < 16U) || (kb > 512U)) {
        kb = 64U;
    }

    return kb;
}

uint32_t BSP_NV_GetStorageBase(void)
{
#if APP_NV_USE_DYNAMIC_FLASH_BASE
    uint32_t kb = (uint32_t)BSP_NV_GetFlashSizeKB();
    return NV_FLASH_BASE_ADDR + (kb * 1024UL) - APP_NV_FLASH_PAGE_SIZE;
#else
    return APP_NV_FLASH_BASE;
#endif
}

uint16_t BSP_NV_GetSlotCount(void)
{
    return (uint16_t)(APP_NV_FLASH_PAGE_SIZE / sizeof(nv_slot_t));
}

static const nv_slot_t *nv_slot_ptr(uint16_t index)
{
    return (const nv_slot_t *)(BSP_NV_GetStorageBase() + ((uint32_t)index * sizeof(nv_slot_t)));
}

static uint8_t nv_slot_is_empty(const nv_slot_t *s)
{
    const volatile uint16_t *p = (const volatile uint16_t *)s;
    uint32_t halfword_count = (uint32_t)(sizeof(nv_slot_t) / 2U);

    for (uint32_t i = 0U; i < halfword_count; i++) {
        if (p[i] != NV_SLOT_EMPTY_VALUE) {
            return 0U;
        }
    }

    return 1U;
}

static uint8_t nv_slot_is_valid(const nv_slot_t *s)
{
    nv_slot_t tmp;

    tmp = *s;

    if (tmp.commit != NV_SLOT_COMMIT_VALUE) return 0U;
    if (tmp.magic != APP_NV_MAGIC) return 0U;
    if (tmp.version != APP_NV_VERSION) return 0U;
    if (tmp.count != APP_MAX_ALARMS) return 0U;
    if (tmp.checksum != nv_checksum(&tmp)) return 0U;

    for (uint8_t i = 0U; i < APP_MAX_ALARMS; i++) {
        if (nv_alarm_is_valid(&tmp.alarms[i]) == 0U) {
            return 0U;
        }
    }

    return 1U;
}

uint16_t BSP_NV_GetUsedSlotCount(void)
{
    uint16_t used = 0U;
    uint16_t total = BSP_NV_GetSlotCount();

    for (uint16_t i = 0U; i < total; i++) {
        if (nv_slot_is_empty(nv_slot_ptr(i)) == 0U) {
            used++;
        }
    }

    return used;
}

uint32_t BSP_NV_GetLastSequence(void)
{
    return g_last_sequence;
}

uint8_t BSP_NV_CountEnabledAlarms(const alarm_cfg_t alarms[], uint8_t count)
{
    uint8_t n = 0U;

    if (alarms == 0) return 0U;

    for (uint8_t i = 0U; (i < count) && (i < APP_MAX_ALARMS); i++) {
        if (alarms[i].enabled != 0U) {
            n++;
        }
    }

    return n;
}

void BSP_NV_DefaultAlarm(alarm_cfg_t *cfg)
{
    cfg->hour = 21U;
    cfg->min = 22U;
    cfg->sec = 23U;
    cfg->enabled = 0U;
}

void BSP_NV_DefaultAlarms(alarm_cfg_t alarms[], uint8_t count)
{
    static const alarm_cfg_t defaults[APP_MAX_ALARMS] = {
        {21U, 22U, 23U, 0U},
        { 6U, 30U,  0U, 0U},
        {12U,  0U,  0U, 0U}
    };

    for (uint8_t i = 0U; i < count; i++) {
        if (i < APP_MAX_ALARMS) {
            alarms[i] = defaults[i];
        } else {
            BSP_NV_DefaultAlarm(&alarms[i]);
        }
    }
}

#if APP_USE_FLASH_NV_STORAGE

static void nv_flash_clear_flags(void)
{
#if defined(FLASH_FLAG_EOP) && defined(FLASH_FLAG_PGERR) && defined(FLASH_FLAG_WRPERR)
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPERR);
#endif
}

static int nv_find_latest_valid_slot(nv_slot_t *out)
{
    uint16_t total = BSP_NV_GetSlotCount();
    uint8_t found = 0U;
    nv_slot_t best;

    memset(&best, 0, sizeof(best));

    for (uint16_t i = 0U; i < total; i++) {
        const nv_slot_t *s = nv_slot_ptr(i);

        if (nv_slot_is_valid(s) != 0U) {
            nv_slot_t tmp = *s;
            if ((found == 0U) || (tmp.sequence > best.sequence)) {
                best = tmp;
                found = 1U;
            }
        }
    }

    if (found == 0U) {
        return 1;
    }

    if (out != 0) {
        *out = best;
    }
    g_last_sequence = best.sequence;
    return 0;
}

static int nv_find_empty_slot_index(uint16_t *index)
{
    uint16_t total = BSP_NV_GetSlotCount();

    for (uint16_t i = 0U; i < total; i++) {
        if (nv_slot_is_empty(nv_slot_ptr(i)) != 0U) {
            *index = i;
            return 0;
        }
    }

    return 1;
}

static uint8_t nv_flash_page_is_erased(void)
{
    const volatile uint16_t *p = (const volatile uint16_t *)BSP_NV_GetStorageBase();
    uint32_t halfword_count = APP_NV_FLASH_PAGE_SIZE / 2U;

    for (uint32_t i = 0U; i < halfword_count; i++) {
        if (p[i] != 0xFFFFU) {
            return 0U;
        }
    }

    return 1U;
}

int BSP_NV_LoadAlarms(alarm_cfg_t alarms[], uint8_t count)
{
    nv_slot_t latest;
    int ret;

    if ((alarms == 0) || (count == 0U)) {
        return -1;
    }

    BSP_NV_DefaultAlarms(alarms, count);

    ret = nv_find_latest_valid_slot(&latest);
    if (ret != 0) {
        return 1;   // Chua co slot hop le nao trong flash
    }

    for (uint8_t i = 0U; (i < count) && (i < APP_MAX_ALARMS); i++) {
        alarms[i] = latest.alarms[i];
    }

    return 0;
}

static int nv_program_halfwords(uint32_t address, const uint16_t *src, uint32_t halfword_count)
{
    for (uint32_t i = 0U; i < halfword_count; i++) {
        if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD,
                              address + (i * 2U),
                              src[i]) != HAL_OK) {
            return -2;
        }
    }
    return 0;
}

int BSP_NV_SaveAlarms(const alarm_cfg_t alarms[], uint8_t count)
{
    nv_slot_t slot;
    nv_slot_t verify;
    FLASH_EraseInitTypeDef erase;
    uint32_t page_error = 0U;
    uint32_t primask;
    uint16_t empty_index = 0U;
    uint32_t save_addr;
    uint32_t halfword_before_commit;
    uint32_t commit_addr;
    uint16_t commit_value = NV_SLOT_COMMIT_VALUE;
    int ret = 0;
    nv_slot_t latest;
    uint32_t next_sequence = 1U;

    if ((alarms == 0) || (count == 0U)) {
        return -10;
    }

    for (uint8_t i = 0U; (i < count) && (i < APP_MAX_ALARMS); i++) {
        if (nv_alarm_is_valid(&alarms[i]) == 0U) {
            return -11;
        }
    }

    // Lay sequence moi nhat neu co, de lan save sau lon hon lan truoc.
    if (nv_find_latest_valid_slot(&latest) == 0) {
        next_sequence = latest.sequence + 1U;
        if (next_sequence == 0U) {
            next_sequence = 1U;
        }
    }

    // Tim slot trong. Neu page da day thi moi erase page.
    if (nv_find_empty_slot_index(&empty_index) != 0) {
        primask = __get_PRIMASK();
        __disable_irq();
        HAL_FLASH_Unlock();
        nv_flash_clear_flags();

        memset(&erase, 0, sizeof(erase));
        erase.TypeErase = FLASH_TYPEERASE_PAGES;
        erase.PageAddress = BSP_NV_GetStorageBase();
        erase.NbPages = 1U;

        if (HAL_FLASHEx_Erase(&erase, &page_error) != HAL_OK) {
            ret = -1;
        } else if (nv_flash_page_is_erased() == 0U) {
            ret = -4;
        }

        HAL_FLASH_Lock();
        if (primask == 0U) {
            __enable_irq();
        }

        if (ret != 0) {
            return ret;
        }

        empty_index = 0U;
    }

    memset(&slot, 0xFF, sizeof(slot));
    slot.magic = APP_NV_MAGIC;
    slot.sequence = next_sequence;
    slot.version = APP_NV_VERSION;
    slot.count = APP_MAX_ALARMS;
    slot.reserved = 0U;

    for (uint8_t i = 0U; i < APP_MAX_ALARMS; i++) {
        if (i < count) {
            slot.alarms[i] = alarms[i];
        } else {
            BSP_NV_DefaultAlarm(&slot.alarms[i]);
        }
    }

    slot.checksum = nv_checksum(&slot);
    slot.commit = 0xFFFFU;  // Chua commit; se ghi commit sau cung
    slot.pad = 0xFFFFU;

    save_addr = BSP_NV_GetStorageBase() + ((uint32_t)empty_index * sizeof(nv_slot_t));
    halfword_before_commit = (uint32_t)(offsetof(nv_slot_t, commit) / 2U);
    commit_addr = save_addr + (uint32_t)offsetof(nv_slot_t, commit);

    primask = __get_PRIMASK();
    __disable_irq();
    HAL_FLASH_Unlock();
    nv_flash_clear_flags();

    // Ghi toan bo slot tru commit truoc.
    ret = nv_program_halfwords(save_addr, (const uint16_t *)&slot, halfword_before_commit);
    if (ret != 0) {
        goto done;
    }

    // Ghi commit cuoi cung. Khi reset doc lai, chi slot co commit = 0 moi duoc xem la hop le.
    if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, commit_addr, commit_value) != HAL_OK) {
        ret = -5;
        goto done;
    }

    verify = *((const nv_slot_t *)save_addr);
    if ((verify.commit != NV_SLOT_COMMIT_VALUE) ||
        (verify.magic != slot.magic) ||
        (verify.sequence != slot.sequence) ||
        (verify.version != slot.version) ||
        (verify.count != slot.count) ||
        (verify.checksum != slot.checksum) ||
        (memcmp(verify.alarms, slot.alarms, sizeof(slot.alarms)) != 0)) {
        ret = -3;
        goto done;
    }

    if (nv_slot_is_valid((const nv_slot_t *)save_addr) == 0U) {
        ret = -6;
        goto done;
    }

    g_last_sequence = slot.sequence;
    ret = 0;

done:
    HAL_FLASH_Lock();
    if (primask == 0U) {
        __enable_irq();
    }
    return ret;
}

#else

int BSP_NV_LoadAlarms(alarm_cfg_t alarms[], uint8_t count)
{
    BSP_NV_DefaultAlarms(alarms, count);
    return 0;
}

int BSP_NV_SaveAlarms(const alarm_cfg_t alarms[], uint8_t count)
{
    (void)alarms;
    (void)count;
    return 0;
}

#endif

int BSP_NV_LoadAlarm(alarm_cfg_t *cfg)
{
    alarm_cfg_t alarms[APP_MAX_ALARMS];
    int ret;

    if (cfg == 0) {
        return -1;
    }

    ret = BSP_NV_LoadAlarms(alarms, APP_MAX_ALARMS);
    *cfg = alarms[0];
    return ret;
}

int BSP_NV_SaveAlarm(const alarm_cfg_t *cfg)
{
    alarm_cfg_t alarms[APP_MAX_ALARMS];

    if (cfg == 0) {
        return -1;
    }

    BSP_NV_DefaultAlarms(alarms, APP_MAX_ALARMS);
    alarms[0] = *cfg;
    return BSP_NV_SaveAlarms(alarms, APP_MAX_ALARMS);
}
