#include "bsp_rtc.h"
#include "app_config.h"

static inline uint8_t bcd2bin(uint8_t value)
{
    return (uint8_t)(((value >> 4U) * 10U) + (value & 0x0FU));
}

static inline uint8_t bin2bcd(uint8_t value)
{
    return (uint8_t)((((value / 10U) & 0x0FU) << 4U) | (value % 10U));
}

static inline void si2c_scl_hi(void)
{
    HAL_GPIO_WritePin(RTC_SCL_GPIO, RTC_SCL_PIN, GPIO_PIN_SET);
}

static inline void si2c_scl_lo(void)
{
    HAL_GPIO_WritePin(RTC_SCL_GPIO, RTC_SCL_PIN, GPIO_PIN_RESET);
}

static inline void si2c_sda_hi(void)
{
    HAL_GPIO_WritePin(RTC_SDA_GPIO, RTC_SDA_PIN, GPIO_PIN_SET);
}

static inline void si2c_sda_lo(void)
{
    HAL_GPIO_WritePin(RTC_SDA_GPIO, RTC_SDA_PIN, GPIO_PIN_RESET);
}

static inline uint8_t si2c_sda_read(void)
{
    return (HAL_GPIO_ReadPin(RTC_SDA_GPIO, RTC_SDA_PIN) == GPIO_PIN_SET) ? 1U : 0U;
}

static void si2c_delay(void)
{
    for (volatile int i = 0; i < 80; i++) {
        __NOP();
    }
}

static void si2c_start(void)
{
    si2c_sda_hi();
    si2c_scl_hi();
    si2c_delay();
    si2c_sda_lo();
    si2c_delay();
    si2c_scl_lo();
    si2c_delay();
}

static void si2c_stop(void)
{
    si2c_sda_lo();
    si2c_delay();
    si2c_scl_hi();
    si2c_delay();
    si2c_sda_hi();
    si2c_delay();
}

static uint8_t si2c_write_byte(uint8_t data)
{
    for (int i = 0; i < 8; i++) {
        if ((data & 0x80U) != 0U) {
            si2c_sda_hi();
        } else {
            si2c_sda_lo();
        }

        si2c_delay();
        si2c_scl_hi();
        si2c_delay();
        si2c_scl_lo();
        si2c_delay();
        data <<= 1U;
    }

    si2c_sda_hi();
    si2c_delay();
    si2c_scl_hi();
    si2c_delay();

    uint8_t ack = (si2c_sda_read() == 0U) ? 1U : 0U;

    si2c_scl_lo();
    si2c_delay();
    return ack;
}

static uint8_t si2c_read_byte(uint8_t ack)
{
    uint8_t data = 0U;

    si2c_sda_hi();
    for (int i = 0; i < 8; i++) {
        data <<= 1U;
        si2c_scl_hi();
        si2c_delay();
        if (si2c_sda_read() != 0U) {
            data |= 1U;
        }
        si2c_scl_lo();
        si2c_delay();
    }

    if (ack != 0U) {
        si2c_sda_lo();
    } else {
        si2c_sda_hi();
    }

    si2c_delay();
    si2c_scl_hi();
    si2c_delay();
    si2c_scl_lo();
    si2c_delay();
    si2c_sda_hi();

    return data;
}

static HAL_StatusTypeDef rtc_read_regs(uint8_t reg, uint8_t *buf, uint16_t len)
{
    si2c_start();

    if (si2c_write_byte((uint8_t)(RTC_I2C_ADDR_HAL | 0U)) == 0U) {
        si2c_stop();
        return HAL_ERROR;
    }

    if (si2c_write_byte(reg) == 0U) {
        si2c_stop();
        return HAL_ERROR;
    }

    si2c_start();

    if (si2c_write_byte((uint8_t)(RTC_I2C_ADDR_HAL | 1U)) == 0U) {
        si2c_stop();
        return HAL_ERROR;
    }

    for (uint16_t i = 0U; i < len; i++) {
        buf[i] = si2c_read_byte((i < (len - 1U)) ? 1U : 0U);
    }

    si2c_stop();
    return HAL_OK;
}

static HAL_StatusTypeDef rtc_write_regs(uint8_t reg, const uint8_t *buf, uint16_t len)
{
    si2c_start();

    if (si2c_write_byte((uint8_t)(RTC_I2C_ADDR_HAL | 0U)) == 0U) {
        si2c_stop();
        return HAL_ERROR;
    }

    if (si2c_write_byte(reg) == 0U) {
        si2c_stop();
        return HAL_ERROR;
    }

    for (uint16_t i = 0U; i < len; i++) {
        if (si2c_write_byte(buf[i]) == 0U) {
            si2c_stop();
            return HAL_ERROR;
        }
    }

    si2c_stop();
    return HAL_OK;
}

uint8_t BSP_RTC_CalcDow(uint16_t year, uint8_t month, uint8_t date)
{
    uint16_t y = year;
    uint8_t m = month;
    uint16_t k;
    uint16_t j;
    uint8_t h;

    if (m < 3U) {
        m = (uint8_t)(m + 12U);
        y--;
    }

    k = (uint16_t)(y % 100U);
    j = (uint16_t)(y / 100U);
    h = (uint8_t)((date + (13U * (m + 1U)) / 5U + k + (k / 4U) + (j / 4U) + (5U * j)) % 7U);

    switch (h) {
        case 0U: return 7U;
        case 1U: return 1U;
        case 2U: return 2U;
        case 3U: return 3U;
        case 4U: return 4U;
        case 5U: return 5U;
        default: return 6U;
    }
}

int BSP_RTC_ReadDateTime(rtc_datetime_t *dt)
{
    uint8_t reg[7];
    uint8_t raw_h;

    if (rtc_read_regs(0x00U, reg, 7U) != HAL_OK) {
        return -1;
    }

    dt->sec = bcd2bin((uint8_t)(reg[0] & 0x7FU));
    dt->min = bcd2bin((uint8_t)(reg[1] & 0x7FU));

    raw_h = reg[2];
    if ((raw_h & 0x40U) != 0U) {
        uint8_t h12 = bcd2bin((uint8_t)(raw_h & 0x1FU));
        uint8_t pm = (raw_h & 0x20U) ? 1U : 0U;
        if (h12 == 12U) {
            h12 = 0U;
        }
        dt->hour = (uint8_t)(h12 + (pm ? 12U : 0U));
    } else {
        dt->hour = bcd2bin((uint8_t)(raw_h & 0x3FU));
    }

    dt->dow = bcd2bin((uint8_t)(reg[3] & 0x07U));
    dt->date = bcd2bin((uint8_t)(reg[4] & 0x3FU));
    dt->month = bcd2bin((uint8_t)(reg[5] & 0x1FU));
    dt->year = (uint16_t)(2000U + bcd2bin(reg[6]));
    return 0;
}

int BSP_RTC_WriteDateTime(const rtc_datetime_t *dt)
{
    uint8_t wr[7];

    wr[0] = bin2bcd(dt->sec);
    wr[1] = bin2bcd(dt->min);
    wr[2] = bin2bcd(dt->hour);
    wr[3] = bin2bcd(dt->dow);
    wr[4] = bin2bcd(dt->date);
    wr[5] = bin2bcd(dt->month);
    wr[6] = bin2bcd((uint8_t)(dt->year % 100U));

    return (rtc_write_regs(0x00U, wr, 7U) == HAL_OK) ? 0 : -1;
}

int BSP_RTC_ReadTemperatureC(int *temp_c)
{
    uint8_t reg[2];
    int8_t msb;
    uint8_t frac2;
    int temp_x4;

    if (rtc_read_regs(0x11U, reg, 2U) != HAL_OK) {
        return -1;
    }

    msb = (int8_t)reg[0];
    frac2 = (uint8_t)(reg[1] >> 6U);
    temp_x4 = ((int)msb * 4) + (int)frac2;

    if (temp_x4 >= 0) {
        *temp_c = (temp_x4 + 2) / 4;
    } else {
        *temp_c = -(((-temp_x4) + 2) / 4);
    }

    return 0;
}

int BSP_RTC_ProbeAndInitDefault(void)
{
    rtc_datetime_t dt;

    if (BSP_RTC_ReadDateTime(&dt) != 0) {
        return -1;
    }

    if ((dt.sec > 59U) || (dt.min > 59U) || (dt.hour > 23U) ||
        (dt.date < 1U) || (dt.date > 31U) ||
        (dt.month < 1U) || (dt.month > 12U) ||
        (dt.year < 2000U) || (dt.year > 2099U)) {

        dt.year = RTC_DEFAULT_YEAR;
        dt.month = RTC_DEFAULT_MONTH;
        dt.date = RTC_DEFAULT_DATE;
        dt.hour = RTC_DEFAULT_HOUR;
        dt.min = RTC_DEFAULT_MIN;
        dt.sec = RTC_DEFAULT_SEC;
        dt.dow = BSP_RTC_CalcDow(dt.year, dt.month, dt.date);

        if (BSP_RTC_WriteDateTime(&dt) != 0) {
            return -2;
        }
        HAL_Delay(20U);
        if (BSP_RTC_ReadDateTime(&dt) != 0) {
            return -3;
        }
    }

    return 0;
}
