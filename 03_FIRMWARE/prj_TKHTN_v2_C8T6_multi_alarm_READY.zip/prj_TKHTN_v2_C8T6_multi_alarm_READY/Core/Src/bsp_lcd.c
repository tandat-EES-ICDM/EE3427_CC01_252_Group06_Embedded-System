#include "bsp_lcd.h"
#include "app_config.h"
#include <stdint.h>

static inline void lcd_rs(uint8_t value)
{
    HAL_GPIO_WritePin(LCD_RS_GPIO, LCD_RS_PIN, value ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

static inline void lcd_e(uint8_t value)
{
    HAL_GPIO_WritePin(LCD_E_GPIO, LCD_E_PIN, value ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

static void lcd_write_data_pins(uint8_t nibble)
{
    HAL_GPIO_WritePin(LCD_D4_GPIO, LCD_D4_PIN, (nibble & 0x01U) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_D5_GPIO, LCD_D5_PIN, (nibble & 0x02U) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_D6_GPIO, LCD_D6_PIN, (nibble & 0x04U) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_D7_GPIO, LCD_D7_PIN, (nibble & 0x08U) ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

static void lcd_short_delay(void)
{
    for (volatile int i = 0; i < 80; i++) {
        __NOP();
    }
}

static void lcd_pulse_enable(void)
{
    lcd_e(1U);
    lcd_short_delay();
    lcd_e(0U);
    lcd_short_delay();
}

static void lcd_send4(uint8_t nibble)
{
    lcd_write_data_pins(nibble & 0x0FU);
    lcd_pulse_enable();
}

static void lcd_send8(uint8_t rs, uint8_t data)
{
    lcd_rs(rs);
    lcd_send4((uint8_t)(data >> 4));
    lcd_send4((uint8_t)(data & 0x0FU));
}

static void lcd_cmd(uint8_t cmd)
{
    lcd_send8(0U, cmd);
    if ((cmd == 0x01U) || (cmd == 0x02U)) {
        HAL_Delay(2U);
    }
}

static void lcd_data(uint8_t data)
{
    lcd_send8(1U, data);
}

static void lcd_goto(uint8_t row, uint8_t col)
{
    lcd_cmd((row == 0U) ? (uint8_t)(0x80U + col) : (uint8_t)(0xC0U + col));
}

void BSP_LCD_CreateChar(uint8_t location, const uint8_t pattern[8])
{
    uint8_t i;

    location &= 0x07U;
    lcd_cmd((uint8_t)(0x40U | (location << 3U)));
    for (i = 0U; i < 8U; i++) {
        lcd_data(pattern[i]);
    }
    lcd_cmd(0x80U);
}

void BSP_LCD_Init(void)
{
    HAL_Delay(50U);
    lcd_rs(0U);

    lcd_send4(0x03U); HAL_Delay(5U);
    lcd_send4(0x03U); HAL_Delay(5U);
    lcd_send4(0x03U); HAL_Delay(5U);
    lcd_send4(0x02U); HAL_Delay(5U);

    lcd_cmd(0x28U);
    lcd_cmd(0x0CU);
    lcd_cmd(0x06U);
    lcd_cmd(0x01U);

#if LCD_BACKLIGHT_PRESENT
    HAL_GPIO_WritePin(LCD_BL_GPIO, LCD_BL_PIN, GPIO_PIN_SET);
#endif
}

void BSP_LCD_Clear(void)
{
    lcd_cmd(0x01U);
}

void BSP_LCD_WriteLine(uint8_t row, const char *buf16)
{
    int i;

    lcd_goto(row, 0U);
    for (i = 0; i < 16; i++) {
        lcd_data((uint8_t)buf16[i]);
    }
}

void BSP_LCD_WriteTwoLines(const char *line0, const char *line1)
{
    BSP_LCD_WriteLine(0U, line0);
    BSP_LCD_WriteLine(1U, line1);
}
