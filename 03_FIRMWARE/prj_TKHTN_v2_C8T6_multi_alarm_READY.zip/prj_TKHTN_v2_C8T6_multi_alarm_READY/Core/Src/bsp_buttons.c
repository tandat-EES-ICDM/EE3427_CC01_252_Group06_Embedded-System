#include "bsp_buttons.h"
#include "app_config.h"

typedef struct {
    GPIO_TypeDef *gpio;
    uint16_t pin;
    uint8_t stable_level;
    uint8_t raw_last;
    uint8_t press_event;
    uint32_t t_edge;
} button_state_t;

static button_state_t g_buttons[BSP_BUTTON_COUNT];

static uint8_t button_read_raw(GPIO_TypeDef *gpio, uint16_t pin)
{
    return (HAL_GPIO_ReadPin(gpio, pin) == GPIO_PIN_RESET) ? 1U : 0U;
}

void BSP_BUTTONS_Init(void)
{
    g_buttons[BSP_BUTTON_SET_TIME].gpio = BTN_SET_TIME_GPIO;
    g_buttons[BSP_BUTTON_SET_TIME].pin  = BTN_SET_TIME_PIN;

    g_buttons[BSP_BUTTON_UP].gpio = BTN_UP_GPIO;
    g_buttons[BSP_BUTTON_UP].pin  = BTN_UP_PIN;

    g_buttons[BSP_BUTTON_DOWN].gpio = BTN_DOWN_GPIO;
    g_buttons[BSP_BUTTON_DOWN].pin  = BTN_DOWN_PIN;

    g_buttons[BSP_BUTTON_SET_ALARM].gpio = BTN_SET_ALARM_GPIO;
    g_buttons[BSP_BUTTON_SET_ALARM].pin  = BTN_SET_ALARM_PIN;

    for (int i = 0; i < BSP_BUTTON_COUNT; i++) {
        g_buttons[i].raw_last = button_read_raw(g_buttons[i].gpio, g_buttons[i].pin);
        g_buttons[i].stable_level = g_buttons[i].raw_last;
        g_buttons[i].press_event = 0U;
        g_buttons[i].t_edge = HAL_GetTick();
    }
}

void BSP_BUTTONS_Task(void)
{
    uint32_t now = HAL_GetTick();

    for (int i = 0; i < BSP_BUTTON_COUNT; i++) {
        uint8_t raw = button_read_raw(g_buttons[i].gpio, g_buttons[i].pin);

        if (raw != g_buttons[i].raw_last) {
            g_buttons[i].raw_last = raw;
            g_buttons[i].t_edge = now;
        }

        if ((now - g_buttons[i].t_edge) >= 10U) {
            if (raw != g_buttons[i].stable_level) {
                g_buttons[i].stable_level = raw;
                if (raw != 0U) {
                    g_buttons[i].press_event = 1U;
                }
            }
        }
    }
}

uint8_t BSP_BUTTONS_WasPressed(bsp_button_id_t id)
{
    uint8_t ret;

    if (id >= BSP_BUTTON_COUNT) {
        return 0U;
    }

    ret = g_buttons[id].press_event;
    g_buttons[id].press_event = 0U;
    return ret;
}

uint8_t BSP_BUTTONS_IsHeld(bsp_button_id_t id)
{
    if (id >= BSP_BUTTON_COUNT) {
        return 0U;
    }

    return g_buttons[id].stable_level;
}
