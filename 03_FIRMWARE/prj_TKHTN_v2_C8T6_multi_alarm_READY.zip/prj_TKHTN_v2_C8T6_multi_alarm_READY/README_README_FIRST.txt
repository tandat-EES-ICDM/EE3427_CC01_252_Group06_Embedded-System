Project: prj_TKHTN_v2_C8T6_multi_alarm_READY
MCU: STM32F103C8T6 / Blue Pill
Clock: 64 MHz
RTC: software I2C on PB6/PB7
Alarm: 3 alarms saved in internal STM32 flash

Important:
- Linker is already changed from FLASH LENGTH = 64K to LENGTH = 63K.
- Last flash page 0x0800FC00..0x0800FFFF is reserved for alarm storage.
- Open this folder in STM32CubeIDE, Clean Project, Build, then Run/Debug.
- After flashing, test by removing ST-Link completely, then power with board supply.

Basic alarm UI:
- SET_ALARM enters alarm setting.
- Field 1 selects Alarm 1/2/3.
- Field 2 enables/disables selected alarm.
- Field 3 sets hour.
- Field 4 sets minute.
- Field 5 sets second.
- Next step saves all alarms to flash.
